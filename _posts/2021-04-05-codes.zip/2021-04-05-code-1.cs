<Query Kind="Expression" />

class A
{
	public readonly Expensive Expensive = new Expensive();
	//...
}
class Expensive { }