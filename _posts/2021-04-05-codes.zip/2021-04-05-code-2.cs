<Query Kind="Expression" />

class A
{
	Expensive _expensive;
	public Expensive Expensive // Ленивое создание экземпляра Expensive
	{
		get
		{
			if (_expensive == null) _expensive = new Expensive();
			return _expensive;
		}
	}
	//...
}

class Expensive { }