<Query Kind="Expression" />

class A
{
	Expensive _expensive;
	readonly object _expenseLock = new object();
	public Expensive Expensive
	{
		get
		{
			lock (_expenseLock)
			{
				if (_expensive == null) 
					_expensive = new Expensive();
				return _expensive;
			}
		}
	}
}

class Expensive { }