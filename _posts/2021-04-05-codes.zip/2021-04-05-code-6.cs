<Query Kind="Expression" />

public static T EnsureInitialized<T>
	(ref T target, Func<T> valueFactory)
{
	if (Volatile.Read(ref target) != null)
	{
		return target;
	}
	return EnsureInitializedCore(ref target, valueFactory);
}
private static T EnsureInitializedCore<T>
	(ref T target, Func<T> valueFactory)
{
	T val = valueFactory();
	if (val == null)
	{
		throw new InvalidOperationException(…);
	}
	Interlocked.CompareExchange(ref target, val, null);
	return target;
}