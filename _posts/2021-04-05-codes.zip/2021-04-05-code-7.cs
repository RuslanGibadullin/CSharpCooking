<Query Kind="Expression" />

static ManualResetEvent _starter = 
	new ManualResetEvent(false);
const int N = 4;
void Main()
{
	A a = new A();
	Thread[] T = new Thread[N];
	for (int i = 0; i < N; i++)
	{
		T[i] = new Thread(() => 
			{ Expensive e = a.Expensive; });
		T[i].Start();
	}
	for (int i = 0; i < N; i++)
		T[i].Join();
	_starter.Set();
	Thread.Sleep(1000); // some work
}
class A
{
	Expensive _expensive;
	public Expensive Expensive
	{
		get
		{
			LazyInitializer.EnsureInitialized
				(ref _expensive, () =>
			{
				Expensive e = new Expensive();
				var tokenReady = new ManualResetEventSlim();
				RegisteredWaitHandle reg = null;
				reg = ThreadPool.RegisterWaitForSingleObject
				(_starter,
				(data, timeOut) =>
				{
					tokenReady.Wait();
					tokenReady.Dispose();
					if (e != _expensive) e.Dispose();
					else e.NotDispose();
					reg.Unregister(_starter);
				},
				null, -1, true);
				tokenReady.Set();
				return e;
			});
			return _expensive;
		}
	}
}
class Expensive : IDisposable
{
	public void Dispose()
	{
		Console.WriteLine($"Object with hash code 
			{this.GetHashCode().ToString()} is disposed.");
	}
	public void NotDispose()
	{
		Console.WriteLine($"Object with hash code 
			{this.GetHashCode().ToString()} not disposed.");
	}
}