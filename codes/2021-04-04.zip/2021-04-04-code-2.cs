<Query Kind="Expression" />

class Program
{
	static bool finish = false;
	static void Main()
	{
		new Thread(ThreadProc).Start();
		int x = 0;
		while (!Volatile.Read(ref finish))
			x++;
	}
	static void ThreadProc()
	{
		Thread.Sleep(1000);
		Volatile.Write(ref finish, true);
	}
}