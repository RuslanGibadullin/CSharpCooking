<Query Kind="Expression" />

class Program
{
	static bool finish = false;
	static void Main()
	{
		new Thread(ThreadProc).Start();
		int x = 0;
		while (!finish)
			x++;
	}
	static void ThreadProc()
	{
		Thread.Sleep(1000);
		finish = true;
	}
}