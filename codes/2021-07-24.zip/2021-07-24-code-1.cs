<Query Kind="Expression" />

struct data
{
	int x;
	int y;
}

// Поток №1
for (int i = 0; i < N; i++)
	data1.x++;
// Поток №2
for (int i = 0; i < N; i++)
	data1.y++;

// Явное выравнивание в памяти
[StructLayout(LayoutKind.Explicit)]
struct data
{
	[FieldOffset(0)] public int x;
	[FieldOffset(64)] public int y;
}