﻿using System;
using System.Text;

namespace ConsoleApp
{
	class Program
	{
		static WeakReference weak;
		static void Main()
		{
			var sb = new StringBuilder("week");
			weak = new WeakReference(sb);
			ShowTarget();
			GC.Collect();
			ShowTarget();
		}
		static void ShowTarget()
		{
			if (weak.Target != null) Console.WriteLine(weak.Target.ToString());
			else Console.WriteLine("null");
		}
	}
}
